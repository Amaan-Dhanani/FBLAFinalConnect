export {default as _, default as Root} from "./components/Textarea.svelte";

export type {
    tTextareaProps as Props,
} from "./types"