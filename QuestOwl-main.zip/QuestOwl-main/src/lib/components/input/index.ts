export {default as _, default as Root} from "./components/input.svelte";

export type {
    tInputProps as Props,
} from "./types"