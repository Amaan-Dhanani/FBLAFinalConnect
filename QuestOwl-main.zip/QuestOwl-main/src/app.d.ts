declare global {
	type user = {
		id: string;
		email: string;
		name: string;
	};

	type auth = {
		id: string;
	};
}

export {};
